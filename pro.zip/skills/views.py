from django.shortcuts import render
from .models import Skill, Category,TeacherProfile
from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from .models import Teacher
from django.shortcuts import render, redirect
from .forms import RatingForm
from django.contrib.auth.models import User

def home(request):
    skills = Skill.objects.all()[:3]
    categories = Category.objects.all()

    context = {
        'skills': skills,
        'categories': categories
    }

    return render(request, 'welcome.html', context)


def explore(request):
    skills=TeacherProfile.objects.all().values()

    return render(request, 'profile.html', {'skills': skills})

def explore(request):
    teachers = TeacherProfile.objects.all()   # 🔥 Fetch ALL teachers

    return render(request, 'explore.html', {
        'teachers': teachers
    })

# views.py

from django.shortcuts import render, redirect
from .models import UserProfile

def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        role = request.POST.get('role')
        skill = request.POST.get('skill')

        UserProfile.objects.create(
            username=username,
            email=email,
            password=password,
            role=role,
            skill=skill
        )

        return redirect('explore')

    return render(request, 'reg.html')


def explore(request):
    skill = request.GET.get('skill')

    if skill:
        teachers = Teacher.objects.filter(skill__icontains=skill)
    else:
        teachers = Teacher.objects.all()

    return render(request, 'explore.html', {'teachers': teachers})


def login_view(request):
    if request.method == 'POST':
       
        username = request.POST.get('username')
        email = request.POST.get('email')
        role = request.POST.get('role') 

        
        if role == 'teacher':
            return redirect('teach') 
        else:
            return redirect('learn') 

    return render(request, 'login.html')


def earn_credit(request, teacher_id):
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    
    teacher.credits += 10
    teacher.save()
    
    messages.success(request, f"You have started learning from {teacher.name}!")
    return redirect('learn_page') 



def teach(request):
    return render(request, 'teach.html')

def profile(request):
    return render(request, 'profile.html')

def index(request):
    return render(request, 'home.html')


def signup_view(request):
    return render(request, 'signup.html')


def how_it_works(request):
    return render(request, 'How_it_Works.html')

def logout(request):
    return render(request, 'logout.html')

def learner(request):
    return render(request, 'learner.html')

def learn(request):
    return render(request, 'learn.html')

def join(request):
    return render(request, 'join.html')


def getstarted(request):
    return render(request, 'login.html')

def message(request):
    return render(request, 'Message.html')



# def explore(request):
#     users =profile.objects.all()
#     return render(request, "explore.html", {"users": users})



def rate_teacher(request, username):
    teacher = User.objects.get(username=username)

    if request.method == "POST":
        form = RatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.teacher = teacher
            rating.learner = request.user
            rating.save()
            return redirect("explore")

    else:
        form = RatingForm()

    return render(request, "rateteacher.html", {"form": form, "teacher": teacher})



def register(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        role = request.POST['role']  # teacher / student

        user = User.objects.create_user(username=username, password=password)

        TeacherProfile.objects.create(user=user, role=role)

    return redirect('reg')


