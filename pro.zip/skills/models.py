from django.db import models



class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Skill(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    rating = models.FloatField(default=0)
    learners = models.IntegerField(default=0)

    def __str__(self):
        return self.title
    
from django.db import models

class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('teacher', 'Teacher'),
        ('learner', 'Learner'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    skill = models.CharField(max_length=100)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)

    def __str__(self):
        return self.name    
    
from django.contrib.auth.models import User

class TeacherProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    skill = models.CharField(max_length=100)
    description = models.TextField()
    experience = models.TextField(blank=True)
    rate = models.IntegerField(default=0)
    credits = models.IntegerField(default=0)  

    def __str__(self):
        return self.name
    
   
class Rating(models.Model):
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name="teacher_rating")
    learner = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField()
    review = models.TextField(blank=True)

    def __str__(self):
        return f"{self.teacher.username} - {self.rating}"
    
from django.db import models
from django.contrib.auth.models import User

from django.db import models

class Teacher(models.Model):
    name = models.CharField(max_length=100)
    skill = models.CharField(max_length=100)
    role = models.CharField(max_length=10)

class Message(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="received_messages")
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender} -> {self.receiver}"
    
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User

@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        TeacherProfile.objects.create(user=instance)