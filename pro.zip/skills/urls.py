from django.urls import path
from .import views

urlpatterns = [
    path('', views.home, name='home'),
    path('index/', views.index, name='index'),
    path('explore/', views.explore, name='explore'),
    path('profile/', views.profile, name='profile'),
    path('teach/', views.teach, name='teach'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.login_view, name='logout'),
    path('signup/', views.register, name='signup'),
    path('how_it_works/', views.how_it_works, name='How_it_Works'),
    path('learner/', views.learner, name='learner'),
    path('learn/', views.learn, name='learn'),
    path('join/', views.join, name='join'),
    path('learn/', views.learn, name='learn'),
    path('learner/', views.learn, name=''),
    path('login/', views.login_view, name='login'),
    path('learn/', views.learn, name='learn'), 
    path('teach/', views.teach, name='teach'), 
    path('rate/<str:username>/', views.rate_teacher, name='rate_teacher'),
    path('message/', views.teach, name='Message'),
    path('register/', views.register, name='register'),
     ]
